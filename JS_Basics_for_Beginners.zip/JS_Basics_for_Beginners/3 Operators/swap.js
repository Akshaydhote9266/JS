let a = 1;
let b = 2;

c = a;
a = b;
b = c;

console.log(a);
console.log(b);