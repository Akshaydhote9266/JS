const circle = "I am Aksh";
const s = circle.split('Aksh');

console.log(circle);
console.log(s);