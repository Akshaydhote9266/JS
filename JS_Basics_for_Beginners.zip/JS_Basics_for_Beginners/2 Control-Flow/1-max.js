
let number = max(5, 3);
console.log(number);

function max(a, b) {
  return (a > b) ? a : b;
}